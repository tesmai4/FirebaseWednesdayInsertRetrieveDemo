package com.example.firebasewednesdaydemo;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    DatabaseReference dbref123;

    EditText fn, sn;
    Button btn_add, btn_nav;

    //ArrayList<User> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbref123 = FirebaseDatabase.getInstance().getReference("_user_");

        fn =findViewById(R.id.et_fn);
        sn =findViewById(R.id.et_sn);

        btn_add =findViewById(R.id.btn_add);
        btn_nav =findViewById(R.id.btn_nav);
     //   dbref123.addListenerForSingleValueEvent(listener);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(fn.getText().length() > 0 && sn.getText().length() >0)
                {
                    User user =new User(fn.getText().toString(), sn.getText().toString());
                    dbref123.child(dbref123.push().getKey()).setValue(user);
                }

            }
        });

        btn_nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigate();
            }
        });
    }
    private void navigate(){
        Intent b =new Intent(this, ReadActivity.class);
        startActivity(b);
    }
}