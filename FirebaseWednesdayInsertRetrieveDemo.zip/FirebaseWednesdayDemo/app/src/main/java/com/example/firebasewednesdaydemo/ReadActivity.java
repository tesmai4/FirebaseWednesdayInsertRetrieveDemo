package com.example.firebasewednesdaydemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//import com.example.firebasewednesdaydemo.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ReadActivity extends AppCompatActivity {

    TextView fn, sn;
    Button left, right;
    DatabaseReference dbref;
    ArrayList<User> list =new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);

        fn =findViewById(R.id.tv_fn);
        sn =findViewById(R.id.tv_sn);
        right =findViewById(R.id.btn_rgt);
        left =findViewById(R.id.btn_lft);

        dbref = FirebaseDatabase.getInstance().getReference().child("_user_");
        dbref.addListenerForSingleValueEvent(listener);
    }
    ValueEventListener listener =new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            for(DataSnapshot dss:snapshot.getChildren())
            {
                list.clear();
                User u=dss.getValue(User.class);
                list.add(u);
            }
            fn.setText(list.get(0).getFn());
            sn.setText(list.get(0).getSn());
             Toast.makeText(ReadActivity.this,list.get(0).getFn().toString(),Toast.LENGTH_LONG).show();
            Toast.makeText(ReadActivity.this,list.get(0).getFn().toString(), Toast.LENGTH_LONG).show();
        }


        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    };

}